<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title> Register </title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="assets/images/favicon.ico" />
      
      <link rel="stylesheet" href="assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="assets/css/backend.css?v=1.0.0">  </head>
  <body class=" ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    
      <div class="wrapper">
    <section class="login-content">
         <div class="container h-100">
            <div class="row align-items-center justify-content-center h-100">
               <div class="col-md-5">
                  <div class="card p-3">
                     <div class="card-body">
                        <div class="auth-logo">
                           <img src="assets/images/logo.png " class="img-fluid  rounded-normal  darkmode-logo" alt="logo">
                           <img src="assets/images/logo-dark.png" class="img-fluid rounded-normal light-logo" alt="logo">
                        </div>
                        <h3 class="mb-3 font-weight-bold text-center">Register</h3>
                        <p class="text-center text-secondary mb-4">Fill data to get registered</p>
                        
                        <div class="mb-5">
                            <p class="line-around text-secondary mb-0"></p>
                        </div>
                        <form method="post" id="registerform">
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label class="text-secondary">Name</label>
                <input class="form-control" type="text" name="name" placeholder="Enter Name" required>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="text-secondary">Age</label>
                <input class="form-control" type="age" name="age" placeholder="Enter age" required>
            </div>
        </div>
        </div>
        <div class="row">
        <div class="col-lg-6 mt-2">
        <div class="form-group">
                <div class="d-flex justify-content-between align-items-center">
                    <label class="text-secondary">Email</label>
                </div>
                <input class="form-control" type="email" name="email" placeholder="Enter Email" required>
            </div>
        </div>
        <div class="col-lg-6 mt-2">
            <div class="form-group">
                <div class="d-flex justify-content-between align-items-center">
                    <label class="text-secondary">Password</label>
                </div>
                <input class="form-control" type="password" name="password" placeholder="Enter Password" required>
            </div>
        </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary btn-block mt-2">Create Account</button>
</form>

                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      </div>
      <script>

document.getElementById('registerform').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('utilities/register.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        iziToast.show({
            title: data.status === 'success' ? 'Success' : 'Error',
            message: data.message,
            color: data.status === 'success' ? 'green' : 'red',
            position: 'topRight',
            timeout: 3000
        });

    })
    .catch(() => {
        iziToast.error({
            title: 'Error',
            message: 'Something went wrong!',
            position: 'topRight'
        });
    });
});

</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
    <!-- Backend Bundle JavaScript -->
    <script src="assets/js/backend-bundle.min.js"></script>
    <!-- Chart Custom JavaScript -->
    <script src="assets/js/customizer.js"></script>
    
    <script src="assets/js/sidebar.js"></script>
    
    <!-- Flextree Javascript-->
    <script src="assets/js/flex-tree.min.js"></script>
    <script src="assets/js/tree.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="assets/js/table-treeview.js"></script>
    
    <!-- SweetAlert JavaScript -->
    <script src="assets/js/sweetalert.js"></script>
    
    <!-- Vectoe Map JavaScript -->
    <script src="assets/js/vector-map-custom.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="assets/js/chart-custom.js"></script>
    <script src="assets/js/charts/01.js"></script>
    <script src="assets/js/charts/02.js"></script>
    
    <!-- slider JavaScript -->
    <script src="assets/js/slider.js"></script>
    
    <!-- Emoji picker -->
    <script src="assets/vendor/emoji-picker-element/index.js" type="module"></script>
    
    
    <!-- app JavaScript -->
    <script src="assets/js/app.js"></script>  </body>
</html>