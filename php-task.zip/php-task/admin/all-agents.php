<?php include '../inc/header.php' ?>
<?php include '../inc/topbar.php' ?>;

<div class="content-page">
    <div class="main-content">
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead class="table-color-heading" style="background-color: #0C2556; color: white;" id="refreshdiv">
                    <tr>
                        <th scope="col" class="text-center">Agent ID</th>
                        <th scope="col">Agent Name</th>
                        <th scope="col">Email/Number</th>
                        <th scope="col">Department</th>
                        <th scope="col">Users assigned</th>
                        <th scope="col">Actions</th>

                    </tr>
                </thead>
                <tbody id="refresh">
                    <?php
                    include '../utilities/conn.php';
                    $sql = "SELECT * FROM users WHERE user_role='agent'";
                    $result = $conn->query($sql);


                    $assignmentCounts = [];
                    $countQuery = "SELECT agent_id, COUNT(*) AS assigned_count FROM assignment GROUP BY agent_id";
                    $countResult = $conn->query($countQuery);
                    while ($countRow = $countResult->fetch_assoc()) {
                        $assignmentCounts[$countRow['agent_id']] = $countRow['assigned_count'];
                    }
                    ?>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $fullName = ucfirst($row['user_name']);
                            $email = $row['email'];
                            $department = $row['user_role'];
                            $employeeId = $row['id'];
                    ?>


                            <tr class="white-space-no-wrap">
                                <td>
                                    <span class="badge bg-danger"><?php echo $employeeId; ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="text-primary"><?php echo $fullName; ?></span>
                                </td>
                                <td><?php echo $email; ?></td>
                                <td>
                                    <span class="badge bg-success"><?php echo $department; ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                        <?php echo $assignmentCounts[$employeeId] ?? 0; ?> Assigned
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-end align-items-center">
                                        <!-- Eye Icon -->
                                        <a href="#" data-toggle="modal" data-target=".assignUserModal" data-agent-id="<?php echo $row['id']; ?>" data-placement="top" title="Assign User">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="text-secondary mx-2" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                                            </svg>

                                        </a>
                                        <!-- Edit Icon -->
                                        <a href="#" class="edit-btn" data-agent-id="<?php echo $row['id']; ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="text-secondary mx-4" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                            </svg>
                                        </a>

                                        <!-- Delete Icon -->
                                        <a href="#" data-id="<?php echo $row['id']; ?>" class="badge bg-danger delete" data-toggle="tooltip" data-placement="top" title="Delete" onclick="confirmDelete(<?php echo $row['id']; ?>); return false;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                    <?php
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No Agents found.</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>

            </table>

        </div>
    </div>
</div>
<?php
include '../utilities/agent-assign-modal.php';
include '../inc/footer.php' ?>