<?php include '../inc/header.php' ?>
<?php include '../inc/topbar.php' ?>;

<div class="content-page">
    <div class="main-content">
    <div class="container-fluid h-100">
            <div class="row align-items-center justify-content-center h-100">
               <div class="col-md-8">
                  <div class="card p-3">
                     <div class="card-body">
                        <h3 class="mb-3 font-weight-bold text-center">Add agent</h3>
                        <p class="text-center text-secondary mb-4">Fill data to get add agents</p>
                        
                        <div class="mb-5">
                            <p class="line-around text-secondary mb-0"></p>
                        </div>
                        <form method="post" id="registerform">
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label class="text-secondary">Name</label>
                <input class="form-control" type="text" name="name" placeholder="Enter Name" required>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="text-secondary">Age</label>
                <input class="form-control" type="age" name="age" placeholder="Enter age" required>
            </div>
        </div>
        </div>
        <div class="row">
        <div class="col-lg-6 mt-2">
        <div class="form-group">
                <div class="d-flex justify-content-between align-items-center">
                    <label class="text-secondary">Email</label>
                </div>
                <input class="form-control" type="email" name="email" placeholder="Enter Email" required>
            </div>
        </div>
        <div class="col-lg-6 mt-2">
            <div class="form-group">
                <div class="d-flex justify-content-between align-items-center">
                    <label class="text-secondary">Password</label>
                </div>
                <input class="form-control" type="password" name="password" placeholder="Enter Password" required>
            </div>
        </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary btn-block mt-2">Register agent</button>
</form>
<script>

document.getElementById('registerform').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('../utilities/register-agent.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        iziToast.show({
            title: data.status === 'success' ? 'Success' : 'Error',
            message: data.message,
            color: data.status === 'success' ? 'green' : 'red',
            position: 'topRight',
            timeout: 3000
        });

    })
    .catch(() => {
        iziToast.error({
            title: 'Error',
            message: 'Something went wrong!',
            position: 'topRight'
        });
    });
});

</script>
                     </div>
                  </div>
               </div>
            </div>
    </div>
</div>
<?php include '../inc/footer.php' ?>