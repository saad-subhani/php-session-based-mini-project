<?php include '../inc/header.php' ?>
<?php include '../inc/topbar.php';
include '../utilities/conn.php';

$totalUsers = $conn->query("SELECT COUNT(*) as total FROM users WHERE user_role = 'user'")->fetch_assoc()['total'];

$totalAgents = $conn->query("SELECT COUNT(*) as total FROM users WHERE user_role = 'agent'")->fetch_assoc()['total'];

$assignedUsers = $conn->query("
    SELECT COUNT(DISTINCT users.id) as total 
    FROM users 
    INNER JOIN assignment ON users.id = assignment.user_id 
    WHERE users.user_role = 'user'
")->fetch_assoc()['total'];

$unassignedUsers = $conn->query("
    SELECT COUNT(*) as total 
    FROM users 
    WHERE user_role = 'user' 
    AND id NOT IN (SELECT user_id FROM assignment)
")->fetch_assoc()['total'];
?>;

<div class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 mb-4 mt-1">
                <div class="d-flex flex-wrap justify-content-between align-items-center">
                    <h4 class="font-weight-bold">Overview</h4>
                    <div class="form-group mb-0 vanila-daterangepicker d-flex flex-row">
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <p class="mb-2 text-secondary">Total Users</p>
                                        <div class="d-flex flex-wrap justify-content-start align-items-center">
                                            <h5 class="mb-0 font-weight-bold"><?= $totalUsers ?></h5>
                                        </div>
                                    </div>
                                    <div>
                                        <img src="../assets/images/icons/customer.png" alt="" height="50">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <p class="mb-2 text-secondary">Total Agents</p>
                                        <div class="d-flex flex-wrap justify-content-start align-items-center">
                                            <h5 class="mb-0 font-weight-bold"><?= $totalAgents ?></h5>
                                        </div>
                                    </div>
                                    <div>
                                        <img src="../assets/images/icons/customer-satisfaction.png" alt="Hot Icon" height="50">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <p class="mb-2 text-secondary">Assigned Users </p>
                                        <div class="d-flex flex-wrap justify-content-start align-items-center">
                                            <h5 class="mb-0 font-weight-bold"><?= $assignedUsers ?></h5>
                                            <p class="mb-0 ml-3">

                                            </p>
                                        </div>
                                    </div>
                                    <div>
                                        <img src="../assets/images/icons/project.png" alt="Projects Icon" height="50">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <p class="mb-2 text-secondary">Unassigned Users</p>
                                        <div class="d-flex flex-wrap justify-content-start align-items-center">
                                            <h5 class="mb-0 font-weight-bold"><?= $unassignedUsers ?></h5>
                                            <p class="mb-0 ml-3">

                                            </p>
                                        </div>
                                    </div>
                                    <div>
                                        <img src="../assets/images/icons/project.png" alt="Projects Icon" height="50">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Page end  -->
    </div>
</div>
</div>

<?php include '../inc/footer.php' ?>