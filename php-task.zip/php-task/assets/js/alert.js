document.addEventListener('DOMContentLoaded', (event) => {
    const alertDuration = 5000; // 5 seconds
    const fadeDuration = 500; // 0.5 second
    const progressInterval = alertDuration / 100; // Calculate interval to decrease width

    function closeAlert(alert) {
        alert.classList.add('fade');
        setTimeout(function() {
            alert.classList.remove('show');
            alert.classList.add('hide');
            alert.addEventListener('transitionend', function() {
                alert.remove();
            });
        }, fadeDuration);
    }

    function closeProgressBar(loader) {
        loader.style.width = '0%';
        setTimeout(function() {
            loader.parentElement.style.display = 'none';
        }, fadeDuration);
    }

    // Set timeout for the alert to disappear after alertDuration milliseconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            closeAlert(alert);
        });
        var loaders = document.querySelectorAll('.progress-bar');
        loaders.forEach(function(loader) {
            closeProgressBar(loader);
        });
    }, alertDuration);

    // Progress bar animation
    var loaders = document.querySelectorAll('.progress-bar');
    loaders.forEach(function(loader) {
        var width = 100;
        var progressIntervalId = setInterval(function() {
            width--;
            loader.style.width = width + '%';

            if (width <= 0) {
                clearInterval(progressIntervalId);
                loader.parentElement.style.display = 'none'; // Hide progress bar when finished
            }
        }, progressInterval);

        // Stop progress bar animation when alert is manually closed
        var alert = loader.closest('.alert');
        if (alert) {
            alert.querySelector('.close').addEventListener('click', function() {
                clearInterval(progressIntervalId);
                closeProgressBar(loader);
            });
        }
    });

    // Stop alert and progress bar when close button is clicked
    document.querySelectorAll('.alert .close').forEach(function(button) {
        button.addEventListener('click', function() {
            var alert = button.closest('.alert');
            if (alert) {
                closeAlert(alert);
            }
            var loader = alert.nextElementSibling.querySelector('.progress-bar');
            if (loader) {
                closeProgressBar(loader);
            }
        });
    });
});
