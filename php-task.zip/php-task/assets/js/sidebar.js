(function(jQuery) {
    "use strict";
    const urlParams = new URLSearchParams(window.location.search);
    const sidebar = urlParams.get('sidebar');
    if (sidebar !== null) {
        $('.iq-sidebar').removeClass('sidebar-dark', 'sidebar-light')
        switch (sidebar) {
            case "0":
                $('.iq-sidebar').addClass('sidebar-dark')
                break;
            case "1":
                $('.iq-sidebar').addClass('sidebar-light')
                break;
            default:
                $('.iq-sidebar').removeClass('sidebar-dark').removeClass('sidebar-light')
                break;
        }
    }
})(jQuery)

   // JavaScript to toggle the dropdown menu
   document.addEventListener("DOMContentLoaded", function() {
    const dropdownItems = document.querySelectorAll('.sidebar-layout > li > a');

    dropdownItems.forEach(item => {
        item.addEventListener('click', function(event) {
            const submenu = this.nextElementSibling;
            const arrow = this.querySelector('.arrow-icon');
            if (submenu) {
                event.preventDefault(); // Prevent the default action of the anchor tag
                submenu.classList.toggle('show');
                arrow.classList.toggle('rotate-up');
            }
        });
    });

    // Stop event propagation for submenu links
    const submenuLinks = document.querySelectorAll('.sidebar-layout ul a');
    submenuLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent the click event from bubbling up to the parent anchor tag
        });
    });
});

