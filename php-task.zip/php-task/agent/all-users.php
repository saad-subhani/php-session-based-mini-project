<?php include '../inc/header.php' ?>
<?php include '../inc/topbar.php' ?>;

<div class="content-page">
    <div class="main-content">
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead class="table-color-heading" style="background-color: #4C175A; color: white;">
                    <tr>
                        <th scope="col" class="text-center">User ID</th>
                        <th scope="col">User Name</th>
                        <th scope="col">Email/Number</th>
                        <th scope="col">Assigned on</th>
                        <th scope="col">Actions</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                    include '../utilities/conn.php';
                    $sql = "SELECT users.*, assignment.assigned_at
                    FROM users
                    INNER JOIN assignment ON users.id = assignment.user_id
                    WHERE users.user_role = 'user'
                    ";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $fullName = ucfirst($row['user_name']);
                            $email = $row['email'];
                            $date = date("F j, Y", strtotime($row['assigned_at']));
                            $employeeId = $row['id'];
                    ?>
                            <tr class="white-space-no-wrap">
                                <td>
                                    <!-- Employee ID -->
                                    <span class="badge bg-danger"><?php echo $employeeId; ?></span>
                                </td>
                                <td class="text-center">
                                    <!-- Employee Name -->
                                    <span class="text-primary"><?php echo $fullName; ?></span>
                                </td>
                                <td><?php echo $email; ?></td>
                                <td>
                                    <!-- Department Badge -->
                                    <span class="badge bg-success"><?php echo $date; ?></span>
                                </td>

                                <td>
                                    <div class="d-flex justify-content-end align-items-center">

                                        <!-- Edit Icon -->
                                        <a href="#"
                                            class="edituser"
                                            data-id="<?php echo $row['id']; ?>"
                                            data-name="<?php echo $row['user_name']; ?>"
                                            data-email="<?php echo $row['email']; ?>"
                                            data-age="<?php echo $row['age']; ?>"
                                            data-toggle="modal"
                                            data-target="#edituserdetails"
                                            data-placement="top"
                                            title="Edit">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="text-secondary mx-4" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                            </svg>
                                        </a>

                                        <!-- Delete Icon -->
                                        <a href="#" data-id="<?php echo $row['id']; ?>" class="badge bg-danger delete" data-toggle="tooltip" data-placement="top" title="Delete" onclick="confirmDelete(<?php echo $row['id']; ?>); return false;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                    <?php
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No users found.</td></tr>";
                    }
                    ?>
                </tbody>

            </table>
            <?php $conn->close(); ?>
        </div>
    </div>
</div>
<?php
include '../utilities/agent-assign-modal.php';
include '../inc/footer.php' ?>