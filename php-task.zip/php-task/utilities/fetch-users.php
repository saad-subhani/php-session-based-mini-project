<?php
require 'conn.php'; // Replace with your actual DB connection file

$query = "SELECT id, user_name FROM users WHERE user_role = 'user'";
$result = mysqli_query($conn, $query);

$agents = [];
while($row = mysqli_fetch_assoc($result)) {
    $agents[] = $row;
}

echo json_encode($agents);
?>
