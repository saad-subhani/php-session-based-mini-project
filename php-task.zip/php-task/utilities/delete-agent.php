<?php
include 'conn.php'; 

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");

    if (!$stmt) {
        echo json_encode([
            'status' => 'error',
            'message' => 'SQL prepare failed: ' . $conn->error
        ]);
        exit();
    }

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Individual deleted successfully.'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Delete failed. No agent or user found with this ID or user is not an agent.'
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Execution failed: ' . $stmt->error
        ]);
    }

    $stmt->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request. Missing ID or wrong method.'
    ]);
}
