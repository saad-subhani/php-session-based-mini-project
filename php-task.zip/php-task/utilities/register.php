<?php
header('Content-Type: application/json');
include'conn.php';

if($_SERVER['REQUEST_METHOD']=== 'POST'){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $userpassword = $_POST['password'];

    $stmt= $conn->prepare("INSERT into users (user_name, email, age, password) VALUES(?,?,?,?)");
    $stmt-> bind_param("ssis", $name, $email, $age, $userpassword);

    if ($stmt->execute()) {
        $response = ['status' => 'success', 'message' => 'User Signed up Successfully'];
    } else {
        $response = ['status' => 'Error', 'message' => $stmt->error];
    }
    echo json_encode($response);
    $stmt->close();
    $conn->close();

};?>