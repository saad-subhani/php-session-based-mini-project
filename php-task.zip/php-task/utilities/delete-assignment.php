<?php
include 'conn.php';
ob_clean();
header('Content-Type: text/plain');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assignment_id'])) {
    $assignment_id = intval($_POST['assignment_id']);

    $stmt = $conn->prepare("DELETE FROM assignment WHERE id = ?");
    $stmt->bind_param("i", $assignment_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "success";
        } else {
            echo "error: assignment not found";
        }
    } else {
        echo "error: could not delete assignment";
    }

    $stmt->close();
} else {
    echo "error: invalid request";
}
?>
