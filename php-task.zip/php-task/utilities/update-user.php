<?php
header('Content-Type: application/json'); // Ensure JSON response

include 'conn.php';

$response = ['status' => 'error'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id    = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $age   = intval($_POST['age'] ?? 0);

    if ($id > 0 && $name && $email && $age) {
        $stmt = $conn->prepare("UPDATE users SET user_name = ?, email = ?, age = ? WHERE id = ? AND user_role = 'user'");
        $stmt->bind_param("ssii", $name, $email, $age, $id);

        if ($stmt->execute()) {
            $response['status'] = 'success';
        } else {
            $response['status'] = 'sql_error';
            $response['message'] = $stmt->error;
        }

        $stmt->close();
    } else {
        $response['status'] = 'invalid_input';
    }

    $conn->close();
} else {
    $response['status'] = 'invalid_method';
}

echo json_encode($response);
?>
