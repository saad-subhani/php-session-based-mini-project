<?php
session_start();
header('Content-Type: application/json');
include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Email and password required.']);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, user_name, password, user_role FROM users WHERE email = ?");
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $conn->error]);
        exit;
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $user_name, $db_password, $role);
        $stmt->fetch();

        // For production: use password_verify($password, $db_password)
        if ($password === $db_password) {
            $_SESSION['id'] = $user_id;
            $_SESSION['user_name'] = $user_name;
            $_SESSION['user_role'] = $role;

            // Assuming folder structure is like: /php_task/admin, /php_task/user, etc.
            $base_url = '/php-task/';
            $redirect_url = $base_url . (
                $role === 'admin' ? 'admin/index.php' :
                ($role === 'user' ? 'user/index.php' :
                ($role === 'agent' ? 'agent/all-users.php' : 'login.php'))
            );

            echo json_encode([
                'status' => 'success',
                'message' => 'Login successful.',
                'redirect' => $redirect_url,
                'user_id' => $user_id,
                'user_name' => $user_name,
                'role' => $role
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Incorrect password.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No user found with that email.']);
    }

    $stmt->close();
    $conn->close();
}
?>
