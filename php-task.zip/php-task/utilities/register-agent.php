<?php
header('Content-Type: application/json');
include'conn.php';

if($_SERVER['REQUEST_METHOD']=== 'POST'){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $userpassword = $_POST['password'];
    $role= "agent";

    $stmt= $conn->prepare("INSERT into users (user_name, email, age, password, user_role) VALUES(?,?,?,?,?)");
    $stmt-> bind_param("ssiss", $name, $email, $age, $userpassword, $role);

    if ($stmt->execute()) {
        $response = ['status' => 'success', 'message' => 'Agent Added Successfully'];
    } else {
        $response = ['status' => 'Error', 'message' => $stmt->error];
    }
    echo json_encode($response);
    $stmt->close();
    $conn->close();

};?>