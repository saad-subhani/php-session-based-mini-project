           <!-- Assign Users Modal -->
           <div class="modal fade assignUserModal" tabindex="-1" role="dialog" aria-labelledby="assignUserModalLabel" aria-hidden="true">
             <div class="modal-dialog modal-lg">
               <div class="modal-content border-0 shadow-lg">
                 <div class="modal-header text-white" style="background-color: #0C2556;">
                   <h5 class="modal-title  text-white">
                     Assign Users to Agent

                   </h5>
                   <button type="button" class="close text-white" data-dismiss="modal">
                     <span>&times;</span>
                   </button>
                 </div>

                 <div class="modal-body">
                   <form id="assignUserForm">
                     <div class="form-group">
                       <label for="userDropdown">Select User to Assign</label>
                       <select class="form-control" id="userDropdown">
                         <option disabled selected>Loading users...</option>
                       </select>
                     </div>
                   </form>
                 </div>

                 <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-dismiss="modal">
                     <i class="fas fa-times"></i> Cancel
                   </button>
                   <button type="submit" class="btn btn-success" id="confirmAssignment" form="assignUserForm">
                     <i class="fas fa-check"></i> Confirm Assignment
                   </button>


                 </div>
               </div>
             </div>
           </div>

           <!-- FontAwesome -->
           <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

           <script>
  let currentAgentId = null;

  function loadUserDropdown() {
    const userDropdown = document.getElementById('userDropdown');
    if (!userDropdown) return;

    fetch('../utilities/fetch-users.php')
      .then(response => response.json())
      .then(users => {
        userDropdown.innerHTML = '<option disabled selected value="">Select a user</option>';
        users.forEach(user => {
          const option = document.createElement('option');
          option.value = user.id;
          option.textContent = user.user_name;
          userDropdown.appendChild(option);
        });
      })
      .catch(error => {
        console.error('Fetch error:', error);
        userDropdown.innerHTML = '<option disabled>Error loading users</option>';
      });
  }


  function rebindAssignModalEvents() {
    loadUserDropdown();


    $('.assignUserModal').off('show.bs.modal').on('show.bs.modal', function (e) {
      const button = e.relatedTarget;
      currentAgentId = button.getAttribute('data-agent-id');
      console.log("Agent ID set to:", currentAgentId);
    });

  
    const confirmBtn = document.getElementById('confirmAssignment');
    if (confirmBtn) {
      confirmBtn.removeEventListener('click', handleAssignClick);
      confirmBtn.addEventListener('click', handleAssignClick);
    }
  }

  function handleAssignClick(e) {
    e.preventDefault();

    const userDropdown = document.getElementById('userDropdown');
    const selectedUserId = userDropdown?.value;

    if (!currentAgentId || !selectedUserId) {
      alert("Please select a user.");
      return;
    }

    const formData = new FormData();
    formData.append('agent_id', currentAgentId);
    formData.append('user_id', selectedUserId);

    fetch('../utilities/assign.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(result => {
      if (result.status === 'success') {
        iziToast.success({
          title: 'Success',
          message: result.message,
          position: 'topRight'
        });
        setTimeout(() => location.reload(), 1000); 
      } else if (result.status === 'exists') {
        iziToast.warning({
          title: 'Already Assigned',
          message: result.message,
          position: 'topRight'
        });
      } else {
        iziToast.error({
          title: 'Error',
          message: result.message,
          position: 'topRight'
        });
      }
    })
    .catch(error => {
      iziToast.error({
        title: 'Error',
        message: 'Request failed. Please try again.',
        position: 'topRight'
      });
      console.error('Assignment error:', error);
    });
  }


  document.addEventListener('DOMContentLoaded', function () {
    rebindAssignModalEvents();
  });
</script>





<!-- EDIT AGENTS MODAL -->
<div class="modal fade editagent" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header with Close Button -->
      <div class="modal-header">
        <h5 class="modal-title" id="myLargeModalLabel">Edit Agent</h5>
        <button type="button" class="close text-black" data-dismiss="modal">
                     <span>&times;</span>
                   </button>
      </div>

      <!-- Modal Body -->
      <div class="modal-body">
        <form>
          <div class="row mb-3">
            <div class="col-md-6">
              <label for="agentName" class="form-label">Name</label>
              <input type="text" class="form-control" id="agentName" placeholder="Enter name">
            </div>
            <div class="col-md-6">
              <label for="agentEmail" class="form-label">Email</label>
              <input type="email" class="form-control" id="agentEmail" placeholder="Enter email">
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label for="agentAge" class="form-label">Age</label>
              <input type="number" class="form-control" id="agentAge" placeholder="Enter age">
            </div>
            <div class="col-md-6">
              <label for="agentPassword" class="form-label">Password</label>
              <input type="password" class="form-control" id="agentPassword" placeholder="Enter password">
            </div>
          </div>
          <div class="d-flex justify-content-end mt-3">
  <button type="button" class="btn btn-success">Confirm Updates</button>
</div>

        </form>
<div class="mt-4">
  <hr>
  <h6 class="text-muted mb-3">Users Assigned</h6>
  <div class="assignment-container d-flex flex-wrap gap-2">
    <!-- Pills will be injected here -->
  </div>
</div>

      </div>

    </div>
  </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function () {
  let assignmentToDelete = null;
  let currentAgentId = null;

  function bindEditButtons() {
    const editButtons = document.querySelectorAll('.edit-btn');

    editButtons.forEach(button => {
      button.addEventListener('click', function (e) {
        e.preventDefault();
        currentAgentId = this.getAttribute('data-agent-id');

        fetch('../utilities/populate-agent-modal.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: 'id=' + encodeURIComponent(currentAgentId),
        })
        .then(response => response.json())
        .then(data => {
          document.getElementById('agentName').value = data.user_name || '';
          document.getElementById('agentEmail').value = data.email || '';
          document.getElementById('agentAge').value = data.age || '';
          document.getElementById('agentPassword').value = data.password || '';

          const container = document.querySelector('.assignment-container');
          container.innerHTML = '';

          if (Array.isArray(data.assignments)) {
            data.assignments.forEach(assign => {
              const pill = document.createElement('span');
              pill.className = 'badge bg-danger text-white d-inline-flex align-items-center';
              pill.setAttribute('data-assignment-id', assign.id);
              pill.style.borderRadius = '50px';
              pill.style.fontSize = '14px';
              pill.style.padding = '0.5rem 0.75rem';
              pill.style.marginRight = '0.5rem';
              pill.style.marginBottom = '0.5rem';

              pill.innerHTML = `
                <span class="me-2">${assign.name}</span>
                <a href="#" class="unassign-link text-white d-flex align-items-center justify-content-center" style="width: 20px; height: 20px;">
                  <i class="fas fa-times"></i>
                </a>
              `;

              container.appendChild(pill);
            });
          }

          const modal = new bootstrap.Modal(document.querySelector('.editagent'));
          modal.show();
        })
        .catch(err => {
          iziToast.error({
            title: 'Error',
            message: 'Error fetching agent data.',
            position: 'topRight'
          });
          console.error(err);
        });
      });
    });
  }

 
  bindEditButtons();

  document.querySelector('.assignment-container').addEventListener('click', function (e) {
    const target = e.target.closest('.unassign-link');
    if (target) {
      e.preventDefault();
      assignmentToDelete = target.closest('span[data-assignment-id]');
      const confirmModal = new bootstrap.Modal(document.getElementById('confirmUnassignModal'));
      confirmModal.show();
    }
  });


  document.getElementById('confirmUnassignBtn').addEventListener('click', function () {
    if (!assignmentToDelete) return;

    const assignmentId = assignmentToDelete.getAttribute('data-assignment-id');

    fetch('../utilities/delete-assignment.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'assignment_id=' + encodeURIComponent(assignmentId),
    })
    .then(res => res.text())
    .then(result => {
      result = result.trim();

      if (result === 'success') {
        iziToast.success({
          title: 'Success',
          message: 'Assignment removed successfully!',
          position: 'topRight'
        });

        const refreshDiv = document.getElementById('refresh');
        fetch(window.location.href)
          .then(res => res.text())
          .then(html => {
            const tempDoc = new DOMParser().parseFromString(html, 'text/html');
            const newContent = tempDoc.getElementById('refresh');
            if (newContent) {
              refreshDiv.innerHTML = newContent.innerHTML;
              bindEditButtons(); 
            }
          });

      } else {
        iziToast.error({
          title: 'Error',
          message: result,
          position: 'topRight'
        });
      }
    })
    .catch(error => {
      iziToast.error({
        title: 'Error',
        message: 'Something went wrong.',
        position: 'topRight'
      });
      console.error(error);
    });
  });

 
  document.querySelector('.editagent .btn-success').addEventListener('click', function () {
    const name = document.getElementById('agentName').value.trim();
    const email = document.getElementById('agentEmail').value.trim();
    const age = document.getElementById('agentAge').value.trim();
    const password = document.getElementById('agentPassword').value.trim();

    if (!name || !email || !age || !password || !currentAgentId) {
      iziToast.error({
        title: 'Error',
        message: 'All fields are required.',
        position: 'topRight'
      });
      return;
    }

    const formData = new URLSearchParams();
    formData.append('id', currentAgentId);
    formData.append('name', name);
    formData.append('email', email);
    formData.append('age', age);
    formData.append('password', password);

    fetch('../utilities/update-agent.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString()
    })
    .then(res => res.text())
    .then(result => {
      result = result.trim();
      if (result === 'success') {
        iziToast.success({
          title: 'Updated',
          message: 'Agent updated successfully.',
          position: 'topRight'
        });

        setTimeout(() => {
          location.reload(); 
        }, 1000);
      } else {
        iziToast.error({
          title: 'Error',
          message: result,
          position: 'topRight'
        });
      }
    })
    .catch(error => {
      iziToast.error({
        title: 'Error',
        message: 'Failed to update agent.',
        position: 'topRight'
      });
      console.error(error);
    });
  });
});
</script>



<!-- Confirmation Modal -->
<div class="modal fade" id="confirmUnassignModal" tabindex="-1" role="dialog" aria-labelledby="confirmUnassignLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Unassign</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span>&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to unassign this user?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button id="confirmUnassignBtn" type="button" class="btn btn-danger">Yes, Unassign</button>
      </div>
    </div>
  </div>
</div>





  <!-- Confirmation Modal -->
  <div class="modal" tabindex="-1" role="dialog" id="deleteConfirmationModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Deletion</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDeleteButton">Yes, Delete</button>
      </div>
    </div>
  </div>
</div>
<script>
  let deleteUserId = null;

  function confirmDelete(id) {
    deleteUserId = id;
    $('#deleteConfirmationModal').modal('show');
  }

  document.getElementById('confirmDeleteButton').addEventListener('click', function () {
    if (!deleteUserId) return;

    fetch('../utilities/delete-agent.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'id=' + encodeURIComponent(deleteUserId)
    })
    .then(res => res.json())
    .then(data => {
      $('#deleteConfirmationModal').modal('hide');
      if (data.status === 'success') {
        iziToast.success({ title: 'Deleted', message: data.message, position: 'topRight' });
        // Optional: remove row or reload
        setTimeout(() => location.reload(), 1000);
      } else {
        iziToast.error({ title: 'Error', message: data.message, position: 'topRight' });
      }
    })
    .catch(error => {
      console.error('Error:', error);
      iziToast.error({ title: 'Error', message: error.message, position: 'topRight' });
    });
  });
</script>


<!-- EDIT USER MODAL -->
<div class="modal fade" id="edituserdetails" tabindex="-1" role="dialog" aria-labelledby="editUserLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <form id="editUserForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="edit_id">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" id="edit_name" class="form-control">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" id="edit_email" class="form-control">
          </div>
          <div class="form-group">
            <label>Age</label>
            <input type="number" name="age" id="edit_age" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save changes</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
 
  document.querySelectorAll('.edituser').forEach(function (button) {
    button.addEventListener('click', function () {
      document.getElementById('edit_id').value = this.getAttribute('data-id');
      document.getElementById('edit_name').value = this.getAttribute('data-name');
      document.getElementById('edit_email').value = this.getAttribute('data-email');
      document.getElementById('edit_age').value = this.getAttribute('data-age');
    });
  });

  const form = document.getElementById('editUserForm'); 
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const id = document.getElementById('edit_id').value;
      const name = document.getElementById('edit_name').value;
      const email = document.getElementById('edit_email').value;
      const age = document.getElementById('edit_age').value;
      const formData = `id=${encodeURIComponent(id)}&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&age=${encodeURIComponent(age)}`;
      fetch('../utilities/update-user.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.status === 'success') {
          iziToast.success({
            title: 'Success',
            message: 'User updated successfully',
            position: 'topRight'
          });
setTimeout(function () {
  location.reload();
}, 1000);


        } else {
          iziToast.error({
            title: 'Error',
            message: data.message || 'Something went wrong',
            position: 'topRight'
          });
        }
      })
      .catch(error => {
        iziToast.error({
          title: 'Error',
          message: 'Network error: ' + error,
          position: 'topRight'
        });
      });
    });
  }
});
</script>



