<?php
include 'conn.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $response = [];

    // Get user data
    $stmt = $conn->prepare("SELECT user_name, email, password, age FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($user_name, $email, $password, $age);
    $stmt->fetch();
    $stmt->close();

    $response['user_name'] = $user_name;
    $response['email'] = $email;
    $response['password'] = $password;
    $response['age'] = $age;

  // Get assigned user names and IDs
$assignments = [];
$stmt2 = $conn->prepare("
SELECT a.id AS assignment_id, u.user_name 
FROM assignment a 
JOIN users u ON a.user_id = u.id 
WHERE a.agent_id = ?
");
$stmt2->bind_param("i", $id);
$stmt2->execute();
$result = $stmt2->get_result();
while ($row = $result->fetch_assoc()) {
    $assignments[] = [
        'id' => $row['assignment_id'],  // This is the assignment table's ID
        'name' => $row['user_name']
    ];
}
$stmt2->close();

$response['assignments'] = $assignments;


    echo json_encode($response);
}
?>
