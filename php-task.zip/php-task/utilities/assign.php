<?php
require 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $agent_id = $_POST['agent_id'] ?? null;
    $user_id = $_POST['user_id'] ?? null;

    if (!$agent_id || !$user_id) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Missing agent or user ID."]);
        exit;
    }

    // Check if user is already assigned
    $checkQuery = $conn->prepare("SELECT * FROM assignment WHERE user_id = ?");
    $checkQuery->bind_param("i", $user_id);
    $checkQuery->execute();
    $checkResult = $checkQuery->get_result();

    if ($checkResult->num_rows > 0) {
        // User already assigned
        echo json_encode(["status" => "exists", "message" => "This user is already assigned to another agent."]);
        exit;
    }
    $checkQuery->close();

    // Proceed with assignment
    $stmt = $conn->prepare("INSERT INTO assignment (agent_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $agent_id, $user_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User assigned successfully."]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
