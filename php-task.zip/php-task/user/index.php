<?php 
include '../inc/header.php'; 
include '../inc/topbar.php'; 
include'../utilities/conn.php';?>

<?php
$user_id = $_SESSION['id'];
$stmt = $conn->prepare("SELECT user_name, age, email FROM users WHERE id = ? AND user_role = 'user'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<div class="content-page">
    <div class="container-fluid">
    <?php if ($user): ?>
    <div class="d-flex justify-content-center align-items-center" style="min-height: 80vh;">
        <div class="card shadow-sm p-4" style="max-width: 500px; width: 100%;">
            <div class="card-body text-center">
                <h4 class="card-title mb-4 text-primary">👤 User Details</h4>
                <p class="mb-2"><strong>Name:</strong> <?php echo htmlspecialchars($user['user_name']); ?></p>
                <p class="mb-2"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p class="mb-0"><strong>Age:</strong> <?php echo htmlspecialchars($user['age']); ?></p>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-danger text-center mt-5" role="alert">
        User data not found.
    </div>
<?php endif; ?>

    </div>
</div>

<?php 
$stmt->close();
$conn->close();

include '../inc/footer.php'; 
?>
