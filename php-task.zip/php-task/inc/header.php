<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>PHP-task</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="../assets/images/favicon.ico" />
    <script src="https://kit.fontawesome.com/4e21418a03.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="../assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="../assets/css/backend.css?v=1.0.0">
</head>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


<body class="  ">
    <!-- loader Start -->
    <div id="loading">
        <div id="loading-center">
        </div>
    </div>
    <?php
    session_start();

    if (!isset($_SESSION['id'], $_SESSION['user_name'], $_SESSION['user_role'])) {
        header('Location: ../login.php');
        exit();
    }

    $current_role = $_SESSION['user_role'];
   

    $uri_parts = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
    $current_folder = $uri_parts[count($uri_parts) - 2] ?? ''; // gets 'admin', 'agent', or 'user'

    $role_folder_map = [
        'admin' => 'admin',
        'agent' => 'agent',
        'user'  => 'user'
    ];

    $expected_folder = $role_folder_map[$current_role] ?? null;

    if ($current_folder !== $expected_folder) {
        header('Location: ../login.php');
        exit();
    }
    ?>



    <div class="wrapper">
        <div class="iq-sidebar  sidebar-default  ">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="../backend/index.php" class="header-logo">
                    <img src="../assets/images/logo.png" class="img-fluid rounded-normal light-logo" alt="logo">
                    <img src="../assets/images/logo-dark.png" class="img-fluid rounded-normal d-none sidebar-light-img" alt="logo">
                    <span>CRM </span>
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>


            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <?php if ($current_role == 'admin'): ?>
                            <!-- Dashboard Section -->
                            <li class="sidebar-layout active">
                                <a href="../admin/index.php" class="svg-icon">
                                    <i>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                                        </svg>
                                    </i>
                                    <span class="ml-2">Dashboard</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($current_role == 'admin'): ?>
                            <li class="px-3 pt-3 pb-2">
                                <span class="text-uppercase small font-weight-bold">Management</span>
                            </li>
                            <li class="sidebar-layout">
                                <a href="all-agents.php" class="svg-icon">
                                    <i>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l1.5 1.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                    </i>
                                    <span class="ml-2">All Agents</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($current_role == 'admin' || $current_role == 'agent'): ?>
                            <li class="sidebar-layout">
                                <a href="all-users.php" class="svg-icon">
                                    <i>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l1.5 1.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                    </i>
                                    <span class="ml-2">All Users</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($current_role == 'admin'): ?>
                            <!-- HR Management Section -->
                            <li class="px-3 pt-3 pb-2">
                                <span class="text-uppercase small font-weight-bold">Management</span>
                            </li>

                            <li class="sidebar-layout">
                                <a href="add-agents.php" class="svg-icon">
                                    <i>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l1.5 1.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                    </i>
                                    <span class="ml-2">Add Agents</span>
                                </a>
                            </li>
                        <?php endif; ?>



                    </ul>
                </nav>

                <div class="pt-5 pb-5"></div>
            </div>';

        </div>